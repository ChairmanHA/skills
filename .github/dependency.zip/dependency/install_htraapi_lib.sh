#!/bin/sh
CURDIR=`pwd`

A=`whoami`


if [ $A != 'root' ]; then
   echo "You have to be root to run this script"
   exit 1;
fi

file=$( ls ./lib/libh2api.so.* )
file=$( basename $file )
version=${file#*so.}
majornum=${version%%.*}


rm -f /etc/h2usb_enum.conf
rm -f /etc/udev/rules.d/h2-cyusb.rules


cp configs/h2usb_enum.conf /etc/
cp configs/h2-cyusb.rules /etc/udev/rules.d/

